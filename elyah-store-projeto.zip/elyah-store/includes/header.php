<?php
require_once __DIR__ . '/auth.php';
$pageTitle = $pageTitle ?? 'Elyah Store';
$activeNav = $activeNav ?? '';
$usuario = usuario_atual();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#dceeff">
    <meta name="description" content="Moda feminina com leveza, elegância e personalidade.">
    <title><?= e($pageTitle) ?> | Elyah Store</title>
    <link rel="stylesheet" href="<?= e(app_url('css/style.css')) ?>">
    <script src="<?= e(app_url('js/app.js')) ?>" defer></script>
</head>
<body>
<a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
<div class="announcement">Elyah Store <span>—</span> elegância que acompanha você</div>
<header class="site-header">
    <div class="header-main container">
        <a class="brand-slot" href="<?= e(app_url('index.php')) ?>" aria-label="Início — espaço para a logo original">
            <span class="brand-placeholder">Logo original<br><small>insira o arquivo aqui</small></span>
        </a>
        <form class="header-search" action="<?= e(app_url('produtos.php')) ?>" method="get" role="search">
            <label class="sr-only" for="busca-global">Pesquisar produtos</label>
            <input id="busca-global" type="search" name="busca" placeholder="O que você procura?" value="<?= e($_GET['busca'] ?? '') ?>">
            <button type="submit" aria-label="Buscar">⌕</button>
        </form>
        <div class="header-actions">
            <?php if ($usuario): ?>
                <?php if (($usuario['papel'] ?? '') === 'administrador'): ?>
                    <a href="<?= e(app_url('admin/index.php')) ?>">Painel</a>
                <?php else: ?>
                    <span class="hello-user">Olá, <?= e(explode(' ', $usuario['nome'])[0]) ?></span>
                <?php endif; ?>
                <form action="<?= e(app_url('logout.php')) ?>" method="post" class="inline-form"><button class="text-button" type="submit">Sair</button></form>
            <?php else: ?>
                <a href="<?= e(app_url('login.php')) ?>">Minha conta</a>
            <?php endif; ?>
            <span class="bag-symbol" aria-hidden="true">♡</span>
        </div>
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-nav">Menu</button>
    </div>
    <nav id="site-nav" class="main-nav container" aria-label="Navegação principal">
        <a class="<?= $activeNav === 'inicio' ? 'is-active' : '' ?>" href="<?= e(app_url('index.php')) ?>">Início</a>
        <a class="<?= $activeNav === 'produtos' ? 'is-active' : '' ?>" href="<?= e(app_url('produtos.php')) ?>">Novidades</a>
        <a class="<?= $activeNav === 'categorias' ? 'is-active' : '' ?>" href="<?= e(app_url('categorias.php')) ?>">Categorias</a>
        <a href="<?= e(app_url('produtos.php')) ?>#destaques">Mais vendidos</a>
        <a href="<?= e(app_url('login.php')) ?>">Login</a>
    </nav>
</header>
<main id="conteudo" class="site-main">
    <?php foreach (flash('') ?? [] as $aviso): ?>
        <div class="container"><div class="notice notice-<?= e($aviso['tipo']) ?>" role="status"><?= e($aviso['mensagem']) ?></div></div>
    <?php endforeach; ?>
