<?php
$imagemProduto = trim((string) ($produto['imagem'] ?? ''));
$urlProduto = app_url('produto.php?id=' . (int) $produto['id']);
?>
<article class="product-card">
    <a class="product-photo" href="<?= e($urlProduto) ?>" aria-label="Ver detalhes de <?= e($produto['nome']) ?>">
        <?php if ($imagemProduto !== ''): ?>
            <img src="<?= e(app_url($imagemProduto)) ?>" alt="<?= e($produto['nome']) ?>" loading="lazy">
        <?php else: ?>
            <span class="product-image-placeholder">Imagem não enviada</span>
        <?php endif; ?>
        <?php if (!empty($produto['novidade'])): ?><span class="product-badge">Novidade</span><?php endif; ?>
        <span class="photo-arrow" aria-hidden="true">↗</span>
    </a>
    <div class="product-meta"><span><?= e($produto['categoria_nome'] ?? '') ?></span><span class="rating-stars" aria-label="Produto demonstrativo">✦</span></div>
    <h3><a href="<?= e($urlProduto) ?>"><?= e($produto['nome']) ?></a></h3>
    <div class="product-bottom"><strong><?= e(dinheiro($produto['preco'])) ?></strong><a class="details-link" href="<?= e($urlProduto) ?>">Ver detalhes</a></div>
</article>
