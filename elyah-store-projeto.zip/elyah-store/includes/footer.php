</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <div class="footer-brand-slot">Espaço para logo original Elyah Store</div>
            <p>Moda feminina para expressar sua essência com leveza.</p>
        </div>
        <div>
            <h2>Explore</h2>
            <a href="<?= e(app_url('produtos.php')) ?>">Todos os produtos</a>
            <a href="<?= e(app_url('categorias.php')) ?>">Categorias</a>
            <a href="<?= e(app_url('login.php')) ?>">Minha conta</a>
        </div>
        <div>
            <h2>Atendimento</h2>
            <p>Projeto acadêmico demonstrativo.<br>Adicione aqui os canais oficiais da loja.</p>
        </div>
    </div>
    <div class="container footer-bottom">© <?= date('Y') ?> Elyah Store <span>•</span> Projeto acadêmico</div>
</footer>
</body>
</html>
