<?php
// Configuração local: copie config.example.php para config.local.php.
$configFile = __DIR__ . '/../config/config.local.php';
if (!file_exists($configFile)) {
    $configFile = __DIR__ . '/../config/config.example.php';
}
$config = require $configFile;

// Ajusta o cookie de sessão para funcionar no XAMPP local e no Preview HTTPS.
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('elyah_store');
session_set_cookie_params([
    'secure' => $https,
    'httponly' => true,
    'samesite' => $https ? 'None' : 'Lax',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Conecta ao MySQL uma vez e reaproveita a conexão nas páginas.
function app_db()
{
    static $pdo;
    global $config;
    if (!$pdo) {
        $db = $config['database'];
        $dsn = 'mysql:host=' . $db['host'] . ';port=' . $db['port'] . ';dbname=' . $db['name'] . ';charset=utf8mb4';
        $pdo = new PDO($dsn, $db['user'], $db['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }
    return $pdo;
}

// Nas páginas públicas, mostra orientação caso o banco ainda não esteja configurado.
function app_db_or_null()
{
    try {
        return app_db();
    } catch (Exception $erro) {
        error_log('Elyah Store: ' . $erro->getMessage());
        return null;
    }
}

function app_url($caminho = '')
{
    global $config;
    return rtrim($config['base_url'], '/') . '/' . ltrim($caminho, '/');
}

function e($texto)
{
    return htmlspecialchars((string) $texto, ENT_QUOTES, 'UTF-8');
}

function dinheiro($valor)
{
    return 'R$ ' . number_format((float) $valor, 2, ',', '.');
}

function redirecionar($caminho)
{
    header('Location: ' . app_url($caminho), true, 303);
    exit;
}

// Guarda uma mensagem para mostrar depois do redirecionamento.
function flash($tipo, $mensagem = null)
{
    if ($mensagem !== null) {
        $_SESSION['flashes'][] = ['tipo' => $tipo, 'mensagem' => $mensagem];
        return;
    }
    $mensagens = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $mensagens;
}

function formatar_lista($texto)
{
    if (!$texto) {
        return [];
    }
    return array_filter(array_map('trim', explode(',', $texto)));
}
