<?php
require_once __DIR__ . '/bootstrap.php';

function usuario_atual()
{
    return $_SESSION['usuario'] ?? null;
}

function administrador_logado()
{
    return (usuario_atual()['papel'] ?? '') === 'administrador';
}

// Coloque esta linha no começo de cada página protegida do painel.
function exigir_administrador()
{
    if (!administrador_logado()) {
        flash('erro', 'Entre com uma conta de administrador para acessar essa área.');
        redirecionar('login.php');
    }
}

function autenticar_usuario($email, $senha)
{
    $pdo = app_db();

    // Primeiro confere a tabela de administradores.
    $stmt = $pdo->prepare('SELECT id, nome, email, senha_hash FROM administradores WHERE email = :email LIMIT 1');
    $stmt->execute(['email' => $email]);
    $usuario = $stmt->fetch();
    if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
        return ['id' => $usuario['id'], 'nome' => $usuario['nome'], 'email' => $usuario['email'], 'papel' => 'administrador'];
    }

    // Se não for administrador, confere como cliente. Cadastro público não cria administradores.
    $stmt = $pdo->prepare('SELECT id, nome, email, senha_hash FROM clientes WHERE email = :email LIMIT 1');
    $stmt->execute(['email' => $email]);
    $usuario = $stmt->fetch();
    if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
        return ['id' => $usuario['id'], 'nome' => $usuario['nome'], 'email' => $usuario['email'], 'papel' => 'cliente'];
    }
    return null;
}

function iniciar_sessao_usuario($usuario)
{
    session_regenerate_id(true);
    $_SESSION['usuario'] = $usuario;
}
