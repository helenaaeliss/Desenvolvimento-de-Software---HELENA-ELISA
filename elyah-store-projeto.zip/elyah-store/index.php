<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Moda feminina com leveza';
$activeNav = 'inicio';
$pdo = app_db_or_null();
$categorias = [];
$novidades = [];
$destaques = [];
if ($pdo) {
    $categorias = $pdo->query('SELECT id, nome, slug FROM categorias WHERE ativa = 1 ORDER BY nome')->fetchAll();
    $destaques = $pdo->query('SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id = p.categoria_id WHERE p.disponivel = 1 AND p.destaque = 1 ORDER BY p.criado_em DESC LIMIT 4')->fetchAll();
    $novidades = $pdo->query('SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id = p.categoria_id WHERE p.disponivel = 1 ORDER BY p.criado_em DESC LIMIT 4')->fetchAll();
}
require __DIR__ . '/includes/header.php';
?>
<section class="hero container">
    <div class="hero-copy">
        <span class="eyebrow">ELYAH STORE · MODA FEMININA</span>
        <h1>Seu estilo,<br><em>sua essência.</em></h1>
        <p>Peças que acompanham você em todos os momentos, com delicadeza e personalidade.</p>
        <a class="button button-dark" href="<?= e(app_url('produtos.php')) ?>">Conheça a coleção <span aria-hidden="true">→</span></a>
        <div class="hero-caption"><span class="silver-line"></span> Uma escolha feita para você</div>
    </div>
    <div class="banner-slot" role="img" aria-label="Espaço reservado para o banner original da Elyah Store">
        <div class="banner-slot-content">
            <span class="banner-slot-label">ESPAÇO PARA O BANNER ORIGINAL</span>
            <p>Substitua esta área pelo arquivo de campanha da Elyah Store.</p>
            <span class="banner-slot-mark" aria-hidden="true">E</span>
        </div>
    </div>
</section>
<section class="service-strip container" aria-label="Diferenciais da loja">
    <div><span class="service-icon">◇</span><div><strong>Escolhas especiais</strong><small>Curadoria com carinho</small></div></div>
    <div><span class="service-icon">↗</span><div><strong>Novidades</strong><small>Peças para cada momento</small></div></div>
    <div><span class="service-icon">▣</span><div><strong>Atendimento</strong><small>Estamos aqui para ajudar</small></div></div>
    <div><span class="service-icon">♡</span><div><strong>Feito para você</strong><small>Encontre seu estilo</small></div></div>
</section>

<section class="section container" id="categorias">
    <div class="section-heading"><div><span class="eyebrow">EXPLORE COM CALMA</span><h2>Categorias em destaque</h2></div><a class="subtle-link" href="<?= e(app_url('categorias.php')) ?>">Ver todas <span>→</span></a></div>
    <?php if ($categorias): ?>
        <div class="category-list">
            <?php foreach ($categorias as $categoria): ?>
                <a class="category-card" href="<?= e(app_url('produtos.php?categoria=' . (int) $categoria['id'])) ?>"><span class="category-orbit" aria-hidden="true">✦</span><strong><?= e($categoria['nome']) ?></strong><small>Descobrir peças</small></a>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="empty-state"><?= $pdo ? 'Em breve, novas categorias para você explorar.' : 'Configure o MySQL e importe o arquivo sql/elyah_store.sql para carregar as categorias de demonstração.' ?></p>
    <?php endif; ?>
</section>

<section class="section section-tint" id="novidades">
    <div class="container">
        <div class="section-heading"><div><span class="eyebrow">ACABARAM DE CHEGAR</span><h2>Novidades</h2></div><a class="subtle-link" href="<?= e(app_url('produtos.php')) ?>">Ver coleção <span>→</span></a></div>
        <?php if ($novidades): ?>
            <div class="product-grid">
                <?php foreach ($novidades as $produto): require __DIR__ . '/includes/card_produto.php'; endforeach; ?>
            </div>
        <?php else: ?><p class="empty-state"><?= $pdo ? 'Ainda não há produtos disponíveis.' : 'Os produtos aparecerão aqui após conectar o banco de dados MySQL.' ?></p><?php endif; ?>
    </div>
</section>

<section class="section container" id="destaques">
    <div class="section-heading"><div><span class="eyebrow">SELEÇÃO ELYAH</span><h2>Mais vendidos</h2></div><a class="subtle-link" href="<?= e(app_url('produtos.php')) ?>">Ver todos <span>→</span></a></div>
    <?php if ($destaques): ?>
        <div class="product-grid">
            <?php foreach ($destaques as $produto): require __DIR__ . '/includes/card_produto.php'; endforeach; ?>
        </div>
    <?php else: ?><p class="empty-state"><?= $pdo ? 'Os produtos em destaque serão exibidos aqui.' : 'Conecte o banco local para consultar os produtos em destaque.' ?></p><?php endif; ?>
</section>

<section class="closing-banner container">
    <div><span class="eyebrow">UM TOQUE DE ELEGÂNCIA</span><h2>Um toque de elegância<br>no seu dia.</h2><p>Descubra peças que valorizam quem você é.</p><a class="button button-dark" href="<?= e(app_url('produtos.php')) ?>">Explorar coleção <span>→</span></a></div>
    <div class="closing-art" aria-hidden="true"><span>E</span><i>✦</i></div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
