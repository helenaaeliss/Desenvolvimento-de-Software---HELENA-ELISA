<?php
require_once __DIR__ . '/includes/auth.php';
$pageTitle = 'Login';
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $senha = (string) ($_POST['senha'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $senha === '') {
        $erro = 'Informe um e-mail válido e sua senha.';
    } else {
        try {
            $usuario = autenticar_usuario($email, $senha);
            if ($usuario) {
                iniciar_sessao_usuario($usuario);
                if ($usuario['papel'] === 'administrador') {
                    redirecionar('admin/index.php');
                }
                redirecionar('index.php');
            }
            $erro = 'E-mail ou senha incorretos.';
        } catch (Exception $erroBanco) {
            error_log('Elyah Store login: ' . $erroBanco->getMessage());
            $erro = 'Não foi possível acessar as contas. Confira a configuração do banco de dados.';
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#dceeff"><title><?= e($pageTitle) ?> | Elyah Store</title><link rel="stylesheet" href="<?= e(app_url('css/style.css')) ?>"><script src="<?= e(app_url('js/app.js')) ?>" defer></script></head>
<body class="auth-body">
<div class="auth-layout">
    <aside class="auth-brand-panel"><a href="<?= e(app_url('index.php')) ?>" class="auth-logo-slot">Logo original<br><small>insira o arquivo aqui</small></a><div class="auth-brand-copy"><span class="eyebrow">ELYAH STORE</span><h1>Vista-se de<br><em>você.</em></h1><p>Peças que celebram sua essência, todos os dias.</p></div><span class="auth-panel-note">Moda feminina · delicadeza em cada detalhe</span></aside>
    <main class="auth-form-panel"><a class="auth-back" href="<?= e(app_url('index.php')) ?>">← Voltar à loja</a><div class="auth-form-wrap"><span class="eyebrow">SUA CONTA ELYAH</span><h2>Que bom ter você por aqui.</h2><p class="auth-lead">Entre para continuar explorando.</p>
        <?php foreach (flash('') ?? [] as $aviso): ?><div class="notice notice-<?= e($aviso['tipo']) ?>" role="status"><?= e($aviso['mensagem']) ?></div><?php endforeach; ?>
        <?php if ($erro !== ''): ?><div class="notice notice-erro" role="alert"><?= e($erro) ?></div><?php endif; ?>
        <form method="post" action="<?= e(app_url('login.php')) ?>" class="form-stack" novalidate>
            <label for="email">E-mail</label><input id="email" name="email" type="email" autocomplete="username" required value="<?= e($_POST['email'] ?? '') ?>" placeholder="voce@email.com">
            <label for="senha">Senha</label><input id="senha" name="senha" type="password" autocomplete="current-password" required placeholder="Sua senha">
            <button class="button button-primary button-wide" type="submit">Entrar</button>
        </form>
        <p class="auth-switch">Ainda não tem cadastro? <a href="<?= e(app_url('cadastro.php')) ?>">Criar conta</a></p>
        <p class="auth-admin-hint">O acesso ao painel é exclusivo para administradores autorizados.</p>
    </div></main>
</div></body></html>
