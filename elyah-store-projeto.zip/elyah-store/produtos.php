<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Produtos';
$activeNav = 'produtos';
$pdo = app_db_or_null();
$categorias = [];
$produtos = [];
$termo = trim((string) ($_GET['busca'] ?? ''));
$categoriaId = filter_input(INPUT_GET, 'categoria', FILTER_VALIDATE_INT) ?: 0;
if ($pdo) {
    $categorias = $pdo->query('SELECT id, nome FROM categorias WHERE ativa = 1 ORDER BY nome')->fetchAll();
    $sql = 'SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id = p.categoria_id WHERE p.disponivel = 1';
    $params = [];
    if ($termo !== '') {
        $sql .= ' AND p.nome LIKE :busca';
        $params['busca'] = '%' . $termo . '%';
    }
    if ($categoriaId > 0) {
        $sql .= ' AND p.categoria_id = :categoria';
        $params['categoria'] = $categoriaId;
    }
    $sql .= ' ORDER BY p.criado_em DESC, p.nome ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $produtos = $stmt->fetchAll();
}
require __DIR__ . '/includes/header.php';
?>
<section class="page-intro container">
    <span class="eyebrow">A COLEÇÃO</span>
    <h1>Peças para o seu momento.</h1>
    <p>Encontre novos favoritos com a delicadeza que combina com você.</p>
</section>
<section class="catalog-section container">
    <form class="catalog-filters" action="<?= e(app_url('produtos.php')) ?>" method="get">
        <label class="filter-search"><span>Buscar produto</span><input type="search" name="busca" value="<?= e($termo) ?>" placeholder="Ex.: vestido azul"></label>
        <label><span>Categoria</span><select name="categoria"><option value="">Todas as categorias</option><?php foreach ($categorias as $categoria): ?><option value="<?= (int) $categoria['id'] ?>" <?= $categoriaId === (int) $categoria['id'] ? 'selected' : '' ?>><?= e($categoria['nome']) ?></option><?php endforeach; ?></select></label>
        <button class="button button-dark" type="submit">Filtrar</button>
        <?php if ($termo !== '' || $categoriaId > 0): ?><a class="clear-filter" href="<?= e(app_url('produtos.php')) ?>">Limpar</a><?php endif; ?>
    </form>
    <div class="catalog-summary"><span><?= $pdo ? count($produtos) . ' produto(s)' : 'Catálogo' ?></span><span>Peças selecionadas para você</span></div>
    <?php if (!$pdo): ?>
        <p class="empty-state">Não foi possível conectar ao banco. Configure `config/config.local.php` e importe `sql/elyah_store.sql` pelo phpMyAdmin.</p>
    <?php elseif ($produtos): ?>
        <div class="product-grid catalog-grid"><?php foreach ($produtos as $produto): require __DIR__ . '/includes/card_produto.php'; endforeach; ?></div>
    <?php else: ?>
        <div class="empty-panel"><span aria-hidden="true">◇</span><h2>Nenhum produto por aqui</h2><p>Não encontramos roupas com esses filtros. Tente outra busca ou volte em breve para ver as novidades.</p><a class="button button-outline" href="<?= e(app_url('produtos.php')) ?>">Ver todos os produtos</a></div>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
