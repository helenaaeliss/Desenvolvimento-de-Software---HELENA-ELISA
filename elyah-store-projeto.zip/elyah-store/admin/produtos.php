<?php
require_once __DIR__ . '/../includes/auth.php';
exigir_administrador();
$pageTitle = 'Gerenciar produtos';
$pdo = app_db();
$produtos = $pdo->query('SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id = p.categoria_id ORDER BY p.criado_em DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<section class="container admin-shell">
    <aside class="admin-sidebar"><span class="eyebrow">ELYAH STORE</span><h1>Administração</h1><nav aria-label="Menu administrativo"><a href="<?= e(app_url('admin/index.php')) ?>">Visão geral</a><a class="is-current" href="<?= e(app_url('admin/produtos.php')) ?>">Produtos</a><a href="<?= e(app_url('admin/produto_form.php')) ?>">Cadastrar produto</a><a href="<?= e(app_url('index.php')) ?>">Ver loja pública</a></nav><p>Conectado como <?= e(usuario_atual()['nome'] ?? 'administrador') ?></p></aside>
    <div class="admin-content"><div class="admin-heading"><div><span class="eyebrow">CATÁLOGO</span><h2>Produtos</h2><p>As alterações aparecem imediatamente na loja pública.</p></div><a class="button button-primary" href="<?= e(app_url('admin/produto_form.php')) ?>">＋ Novo produto</a></div>
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Produto</th><th>Categoria</th><th>Preço</th><th>Situação</th><th>Ações</th></tr></thead><tbody>
        <?php foreach ($produtos as $produto): ?><tr><td><div class="table-product"><?php if ($produto['imagem']): ?><img src="<?= e(app_url($produto['imagem'])) ?>" alt="" loading="lazy"><?php endif; ?><strong><?= e($produto['nome']) ?></strong></div></td><td><?= e($produto['categoria_nome']) ?></td><td><?= e(dinheiro($produto['preco'])) ?></td><td><span class="status-pill <?= $produto['disponivel'] ? 'is-on' : 'is-off' ?>"><?= $produto['disponivel'] ? 'Disponível' : 'Oculto' ?></span></td><td class="table-actions"><a href="<?= e(app_url('admin/produto_form.php?id=' . (int) $produto['id'])) ?>">Editar</a><form action="<?= e(app_url('admin/produto_excluir.php')) ?>" method="post" onsubmit="return confirm('Tem certeza que deseja excluir este produto?');"><input type="hidden" name="id" value="<?= (int) $produto['id'] ?>"><button class="text-button danger-text" type="submit">Excluir</button></form></td></tr><?php endforeach; ?>
        <?php if (!$produtos): ?><tr><td colspan="5">Nenhum produto cadastrado ainda.</td></tr><?php endif; ?>
        </tbody></table></div>
    </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
