<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$pageTitle = 'Primeiro administrador';

// Por segurança, esta página só funciona no computador local.
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($ip, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('A configuração inicial só pode ser feita pelo próprio computador.');
}

$pdo = app_db_or_null();
$erro = '';
$criado = false;
$quantidade = $pdo ? (int) $pdo->query('SELECT COUNT(*) FROM administradores')->fetchColumn() : -1;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $pdo && $quantidade === 0) {
    $nome = trim((string) ($_POST['nome'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $senha = (string) ($_POST['senha'] ?? '');
    $confirmacao = (string) ($_POST['confirmacao'] ?? '');
    if (strlen($nome) < 3 || strlen($nome) > 120) {
        $erro = 'Informe seu nome (entre 3 e 120 caracteres).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $erro = 'Informe um e-mail válido.';
    } elseif (strlen($senha) < 12) {
        $erro = 'Use uma senha com pelo menos 12 caracteres.';
    } elseif ($senha !== $confirmacao) {
        $erro = 'A confirmação de senha não confere.';
    } else {
        $cliente = $pdo->prepare('SELECT id FROM clientes WHERE email = :email');
        $cliente->execute(['email' => $email]);
        if ($cliente->fetch()) {
            $erro = 'Esse e-mail já está cadastrado como cliente. Use outro e-mail.';
        } else {
            $stmt = $pdo->prepare('INSERT INTO administradores (nome, email, senha_hash) VALUES (:nome, :email, :senha_hash)');
            $stmt->execute(['nome' => $nome, 'email' => $email, 'senha_hash' => password_hash($senha, PASSWORD_DEFAULT)]);
            $criado = true;
            $quantidade = 1;
            flash('sucesso', 'Administrador criado. Entre para abrir o painel.');
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= e($pageTitle) ?> | Elyah Store</title><link rel="stylesheet" href="<?= e(app_url('css/style.css')) ?>"></head>
<body class="auth-body"><div class="auth-layout"><aside class="auth-brand-panel"><a href="<?= e(app_url('index.php')) ?>" class="auth-logo-slot">Logo original<br><small>insira o arquivo aqui</small></a><div class="auth-brand-copy"><span class="eyebrow">CONFIGURAÇÃO INICIAL</span><h1>Conta de<br><em>administração.</em></h1><p>Este formulário é para criar a primeira conta administrativa no computador local.</p></div></aside>
<main class="auth-form-panel"><a class="auth-back" href="<?= e(app_url('index.php')) ?>">← Voltar à loja</a><div class="auth-form-wrap"><span class="eyebrow">PRIMEIRO ACESSO</span><h2>Criar administrador</h2>
<?php if (!$pdo): ?><div class="notice notice-erro">Banco indisponível. Importe o SQL e configure config/config.local.php.</div>
<?php elseif ($quantidade > 0 || $criado): ?><div class="notice notice-sucesso">A primeira conta já foi criada. Remova este arquivo depois de testar a instalação e entre pelo login.</div><a class="button button-primary button-wide" href="<?= e(app_url('login.php')) ?>">Ir para o login</a>
<?php else: ?>
<p class="auth-lead">Escolha seus próprios dados. A senha será armazenada com hash.</p><?php if ($erro !== ''): ?><div class="notice notice-erro" role="alert"><?= e($erro) ?></div><?php endif; ?>
<form method="post" class="form-stack"><label for="nome">Nome completo</label><input id="nome" name="nome" required maxlength="120" value="<?= e($_POST['nome'] ?? '') ?>"><label for="email">E-mail administrativo</label><input id="email" name="email" type="email" required maxlength="190" value="<?= e($_POST['email'] ?? '') ?>"><label for="senha">Senha <span class="field-hint">mínimo de 12 caracteres</span></label><input id="senha" name="senha" type="password" minlength="12" required><label for="confirmacao">Confirme a senha</label><input id="confirmacao" name="confirmacao" type="password" minlength="12" required><button class="button button-primary button-wide" type="submit">Criar primeiro administrador</button></form>
<?php endif; ?></div></main></div></body></html>
