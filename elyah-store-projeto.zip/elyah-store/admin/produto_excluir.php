<?php
require_once __DIR__ . '/../includes/auth.php';
exigir_administrador();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Use o formulário do painel para excluir.');
}
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT) ?: 0;
if ($id < 1) {
    flash('erro', 'Produto inválido.');
    redirecionar('admin/produtos.php');
}
$pdo = app_db();
$stmt = $pdo->prepare('SELECT imagem FROM produtos WHERE id = :id');
$stmt->execute(['id' => $id]);
$produto = $stmt->fetch();
if (!$produto) {
    flash('erro', 'O produto já não está disponível.');
    redirecionar('admin/produtos.php');
}
$delete = $pdo->prepare('DELETE FROM produtos WHERE id = :id');
$delete->execute(['id' => $id]);
if (str_starts_with((string) $produto['imagem'], 'uploads/')) {
    $path = __DIR__ . '/../' . $produto['imagem'];
    if (is_file($path)) { unlink($path); }
}
flash('sucesso', 'Produto excluído do catálogo.');
redirecionar('admin/produtos.php');
