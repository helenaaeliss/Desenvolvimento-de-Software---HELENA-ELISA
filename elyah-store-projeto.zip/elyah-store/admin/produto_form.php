<?php
require_once __DIR__ . '/../includes/auth.php';
exigir_administrador();
$pageTitle = 'Produto';
$pdo = app_db();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$produto = ['nome' => '', 'preco' => '', 'descricao' => '', 'tamanhos' => '', 'cores' => '', 'categoria_id' => '', 'imagem' => '', 'disponivel' => 1, 'destaque' => 0, 'novidade' => 0];
if ($id > 0) {
    $stmt = $pdo->prepare('SELECT * FROM produtos WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $produtoCarregado = $stmt->fetch();
    if (!$produtoCarregado) {
        http_response_code(404);
        exit('Produto não encontrado.');
    }
    $produto = $produtoCarregado;
}
$categorias = $pdo->query('SELECT id, nome FROM categorias WHERE ativa = 1 ORDER BY nome')->fetchAll();
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produto['nome'] = trim((string) ($_POST['nome'] ?? ''));
    $produto['descricao'] = trim((string) ($_POST['descricao'] ?? ''));
    $produto['tamanhos'] = trim((string) ($_POST['tamanhos'] ?? ''));
    $produto['cores'] = trim((string) ($_POST['cores'] ?? ''));
    $produto['categoria_id'] = filter_var($_POST['categoria_id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
    $produto['disponivel'] = isset($_POST['disponivel']) ? 1 : 0;
    $produto['destaque'] = isset($_POST['destaque']) ? 1 : 0;
    $produto['novidade'] = isset($_POST['novidade']) ? 1 : 0;
    $precoDigitado = trim((string) ($_POST['preco'] ?? ''));
    $precoNormalizado = str_replace(',', '.', $precoDigitado);
    $arquivoNovo = null;
    $imagemAtual = (string) ($produto['imagem'] ?? '');

    // Confere os campos obrigatórios antes de gravar no banco.
    if ($produto['nome'] === '' || strlen($produto['nome']) > 150) {
        $erro = 'Informe o nome do produto (até 150 caracteres).';
    } elseif (!preg_match('/^\d{1,8}(?:[,.]\d{1,2})?$/', $precoDigitado) || (float) $precoNormalizado <= 0) {
        $erro = 'Informe um preço maior que zero, com até duas casas decimais.';
    } elseif (strlen($produto['descricao']) < 10) {
        $erro = 'Escreva uma descrição com pelo menos 10 caracteres.';
    } elseif ($produto['tamanhos'] === '' || strlen($produto['tamanhos']) > 160) {
        $erro = 'Informe os tamanhos disponíveis (máximo de 160 caracteres).';
    } elseif ($produto['cores'] === '' || strlen($produto['cores']) > 160) {
        $erro = 'Informe as cores disponíveis (máximo de 160 caracteres).';
    } else {
        $catStmt = $pdo->prepare('SELECT id FROM categorias WHERE id = :id AND ativa = 1');
        $catStmt->execute(['id' => $produto['categoria_id']]);
        if (!$catStmt->fetch()) {
            $erro = 'Selecione uma categoria válida.';
        }
    }

    // Aceita somente JPG, PNG ou WEBP com até 5 MB.
    $upload = $_FILES['imagem'] ?? null;
    if ($erro === '' && $upload && $upload['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($upload['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'])) {
            $erro = 'Não foi possível receber a imagem enviada.';
        } elseif ((int) $upload['size'] <= 0 || (int) $upload['size'] > 5 * 1024 * 1024) {
            $erro = 'A imagem deve ter no máximo 5 MB.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($upload['tmp_name']);
            $tiposPermitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            if (!isset($tiposPermitidos[$mime])) {
                $erro = 'Formato inválido. Envie uma imagem JPG, PNG ou WEBP.';
            } else {
                $nomeSeguro = bin2hex(random_bytes(16)) . '.' . $tiposPermitidos[$mime];
                $destino = __DIR__ . '/../uploads/' . $nomeSeguro;
                if (!move_uploaded_file($upload['tmp_name'], $destino)) {
                    $erro = 'Não foi possível salvar a imagem enviada.';
                } else {
                    $arquivoNovo = 'uploads/' . $nomeSeguro;
                }
            }
        }
    } elseif ($erro === '' && $id === 0) {
        $erro = 'Envie uma imagem para o produto.';
    }

    if ($erro === '') {
        $imagemFinal = $arquivoNovo ?? $imagemAtual;
        try {
            if ($id > 0) {
                $stmt = $pdo->prepare('UPDATE produtos SET categoria_id=:categoria_id, nome=:nome, preco=:preco, descricao=:descricao, tamanhos=:tamanhos, cores=:cores, imagem=:imagem, disponivel=:disponivel, destaque=:destaque, novidade=:novidade WHERE id=:id');
                $stmt->execute(['categoria_id' => $produto['categoria_id'], 'nome' => $produto['nome'], 'preco' => $precoNormalizado, 'descricao' => $produto['descricao'], 'tamanhos' => $produto['tamanhos'], 'cores' => $produto['cores'], 'imagem' => $imagemFinal, 'disponivel' => $produto['disponivel'], 'destaque' => $produto['destaque'], 'novidade' => $produto['novidade'], 'id' => $id]);
            } else {
                $stmt = $pdo->prepare('INSERT INTO produtos (categoria_id, nome, preco, descricao, tamanhos, cores, imagem, disponivel, destaque, novidade) VALUES (:categoria_id, :nome, :preco, :descricao, :tamanhos, :cores, :imagem, :disponivel, :destaque, :novidade)');
                $stmt->execute(['categoria_id' => $produto['categoria_id'], 'nome' => $produto['nome'], 'preco' => $precoNormalizado, 'descricao' => $produto['descricao'], 'tamanhos' => $produto['tamanhos'], 'cores' => $produto['cores'], 'imagem' => $imagemFinal, 'disponivel' => $produto['disponivel'], 'destaque' => $produto['destaque'], 'novidade' => $produto['novidade']]);
            }
            if ($arquivoNovo && str_starts_with($imagemAtual, 'uploads/')) {
                $imagemAntigaPath = __DIR__ . '/../' . $imagemAtual;
                if (is_file($imagemAntigaPath)) { unlink($imagemAntigaPath); }
            }
            flash('sucesso', $id > 0 ? 'Produto atualizado com sucesso.' : 'Produto cadastrado com sucesso.');
            redirecionar('admin/produtos.php');
        } catch (Exception $erroBanco) {
            if ($arquivoNovo && is_file(__DIR__ . '/../' . $arquivoNovo)) { unlink(__DIR__ . '/../' . $arquivoNovo); }
            error_log('Elyah Store produto: ' . $erroBanco->getMessage());
            $erro = 'Não foi possível salvar o produto. Verifique os dados e tente novamente.';
        }
    }
}
require __DIR__ . '/../includes/header.php';
?>
<section class="container admin-shell">
    <aside class="admin-sidebar"><span class="eyebrow">ELYAH STORE</span><h1>Administração</h1><nav aria-label="Menu administrativo"><a href="<?= e(app_url('admin/index.php')) ?>">Visão geral</a><a href="<?= e(app_url('admin/produtos.php')) ?>">Produtos</a><a class="is-current" href="<?= e(app_url('admin/produto_form.php')) ?>">Cadastrar produto</a><a href="<?= e(app_url('index.php')) ?>">Ver loja pública</a></nav></aside>
    <div class="admin-content"><div class="admin-heading"><div><span class="eyebrow">CATÁLOGO</span><h2><?= $id > 0 ? 'Editar produto' : 'Novo produto' ?></h2><p>Os dados salvos serão exibidos na loja pública.</p></div><a class="subtle-link" href="<?= e(app_url('admin/produtos.php')) ?>">← Voltar aos produtos</a></div>
        <?php if ($erro !== ''): ?><div class="notice notice-erro" role="alert"><?= e($erro) ?></div><?php endif; ?>
        <form class="admin-form" method="post" enctype="multipart/form-data" action="<?= e(app_url('admin/produto_form.php' . ($id > 0 ? '?id=' . $id : ''))) ?>">
            <div class="form-grid"><label>Nome do produto<input name="nome" required maxlength="150" value="<?= e($produto['nome']) ?>"></label><label>Preço (R$)<input name="preco" inputmode="decimal" required placeholder="0,00" value="<?= e($produto['preco']) ?>"></label>
            <label>Categoria<select name="categoria_id" required><option value="">Selecione</option><?php foreach ($categorias as $categoria): ?><option value="<?= (int) $categoria['id'] ?>" <?= (int) $produto['categoria_id'] === (int) $categoria['id'] ? 'selected' : '' ?>><?= e($categoria['nome']) ?></option><?php endforeach; ?></select></label>
            <label>Tamanhos disponíveis<input name="tamanhos" required maxlength="160" placeholder="P, M, G" value="<?= e($produto['tamanhos']) ?>"></label><label>Cores disponíveis<input name="cores" required maxlength="160" placeholder="Azul, branco" value="<?= e($produto['cores']) ?>"></label>
            <label class="full-field">Descrição<textarea name="descricao" rows="5" required><?= e($produto['descricao']) ?></textarea></label>
            <label class="full-field">Imagem do produto <span class="field-hint">JPG, PNG ou WEBP; máximo de 5 MB<?= $id > 0 ? '. Envie somente se quiser substituir a atual.' : '' ?></span><input type="file" name="imagem" accept="image/jpeg,image/png,image/webp" <?= $id === 0 ? 'required' : '' ?>></label>
            <?php if (!empty($produto['imagem'])): ?><div class="current-image full-field"><span>Imagem atual</span><img src="<?= e(app_url($produto['imagem'])) ?>" alt="Prévia de <?= e($produto['nome']) ?>"></div><?php endif; ?>
            <div class="checkbox-row full-field"><label><input type="checkbox" name="disponivel" value="1" <?= $produto['disponivel'] ? 'checked' : '' ?>> Disponível no catálogo público</label><label><input type="checkbox" name="destaque" value="1" <?= $produto['destaque'] ? 'checked' : '' ?>> Em destaque</label><label><input type="checkbox" name="novidade" value="1" <?= $produto['novidade'] ? 'checked' : '' ?>> Novidade</label></div></div>
            <div class="form-actions"><button class="button button-primary" type="submit">Salvar produto</button><a class="button button-outline" href="<?= e(app_url('admin/produtos.php')) ?>">Cancelar</a></div>
        </form>
    </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
