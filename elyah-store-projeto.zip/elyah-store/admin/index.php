<?php
require_once __DIR__ . '/../includes/auth.php';
exigir_administrador();
$pageTitle = 'Painel administrativo';
$pdo = app_db();
$totalProdutos = (int) $pdo->query('SELECT COUNT(*) FROM produtos')->fetchColumn();
$totalDisponiveis = (int) $pdo->query('SELECT COUNT(*) FROM produtos WHERE disponivel = 1')->fetchColumn();
$totalClientes = (int) $pdo->query('SELECT COUNT(*) FROM clientes')->fetchColumn();
$recentes = $pdo->query('SELECT p.id, p.nome, p.preco, p.disponivel, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id = p.categoria_id ORDER BY p.criado_em DESC LIMIT 5')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<section class="container admin-shell">
    <aside class="admin-sidebar"><span class="eyebrow">ELYAH STORE</span><h1>Administração</h1><nav aria-label="Menu administrativo"><a class="is-current" href="<?= e(app_url('admin/index.php')) ?>">Visão geral</a><a href="<?= e(app_url('admin/produtos.php')) ?>">Produtos</a><a href="<?= e(app_url('admin/produto_form.php')) ?>">Cadastrar produto</a><a href="<?= e(app_url('index.php')) ?>">Ver loja pública</a></nav><p>Conectado como <?= e(usuario_atual()['nome'] ?? 'administrador') ?></p></aside>
    <div class="admin-content"><div class="admin-heading"><div><span class="eyebrow">ÁREA RESTRITA</span><h2>Painel da loja</h2><p>Gerencie os produtos apresentados na área pública.</p></div><a class="button button-primary" href="<?= e(app_url('admin/produto_form.php')) ?>">＋ Novo produto</a></div>
        <div class="stats-grid"><article><span>Produtos cadastrados</span><strong><?= $totalProdutos ?></strong></article><article><span>Disponíveis na loja</span><strong><?= $totalDisponiveis ?></strong></article><article><span>Clientes cadastradas</span><strong><?= $totalClientes ?></strong></article></div>
        <div class="admin-table-wrap"><div class="admin-table-heading"><h3>Produtos recentes</h3><a href="<?= e(app_url('admin/produtos.php')) ?>">Ver todos →</a></div><table class="admin-table"><thead><tr><th>Produto</th><th>Categoria</th><th>Preço</th><th>Situação</th></tr></thead><tbody>
            <?php foreach ($recentes as $item): ?><tr><td><?= e($item['nome']) ?></td><td><?= e($item['categoria_nome']) ?></td><td><?= e(dinheiro($item['preco'])) ?></td><td><span class="status-pill <?= $item['disponivel'] ? 'is-on' : 'is-off' ?>"><?= $item['disponivel'] ? 'Disponível' : 'Oculto' ?></span></td></tr><?php endforeach; ?>
            <?php if (!$recentes): ?><tr><td colspan="4">Nenhum produto cadastrado.</td></tr><?php endif; ?>
        </tbody></table></div>
    </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
