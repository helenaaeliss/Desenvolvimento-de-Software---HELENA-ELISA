<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Categorias';
$activeNav = 'categorias';
$pdo = app_db_or_null();
$categorias = [];
if ($pdo) {
    $categorias = $pdo->query('SELECT c.id, c.nome, c.slug, COUNT(p.id) AS total FROM categorias c LEFT JOIN produtos p ON p.categoria_id = c.id AND p.disponivel = 1 WHERE c.ativa = 1 GROUP BY c.id, c.nome, c.slug ORDER BY c.nome')->fetchAll();
}
require __DIR__ . '/includes/header.php';
?>
<section class="page-intro container"><span class="eyebrow">ESCOLHA O SEU ESTILO</span><h1>Categorias</h1><p>Explore a seleção Elyah por tipo de peça.</p></section>
<section class="section container">
    <?php if (!$pdo): ?><p class="empty-state">Configure o MySQL para carregar as categorias.</p>
    <?php elseif ($categorias): ?><div class="category-list category-list-large">
        <?php foreach ($categorias as $categoria): ?><a class="category-card" href="<?= e(app_url('produtos.php?categoria=' . (int) $categoria['id'])) ?>"><span class="category-orbit" aria-hidden="true">✦</span><strong><?= e($categoria['nome']) ?></strong><small><?= (int) $categoria['total'] ?> produto(s) <span aria-hidden="true">→</span></small></a><?php endforeach; ?>
    </div><?php else: ?><div class="empty-panel"><h2>Categorias em breve</h2><p>Adicione categorias no banco para exibi-las nesta página.</p></div><?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
