<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Detalhes do produto';
$activeNav = 'produtos';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$pdo = app_db_or_null();
$produto = null;
if ($pdo && $id > 0) {
    $stmt = $pdo->prepare('SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id = p.categoria_id WHERE p.id = :id AND p.disponivel = 1 LIMIT 1');
    $stmt->execute(['id' => $id]);
    $produto = $stmt->fetch() ?: null;
}
if (!$produto && $pdo) {
    http_response_code(404);
}
require __DIR__ . '/includes/header.php';
?>
<?php if (!$pdo): ?>
    <section class="container empty-panel"><h1>Catálogo indisponível</h1><p>Conecte o banco de dados para consultar os detalhes dos produtos.</p><a class="button button-outline" href="<?= e(app_url('produtos.php')) ?>">Voltar aos produtos</a></section>
<?php elseif (!$produto): ?>
    <section class="container empty-panel"><span aria-hidden="true">◇</span><h1>Não encontramos esse produto</h1><p>Ele pode ter sido removido ou não está disponível no momento.</p><a class="button button-outline" href="<?= e(app_url('produtos.php')) ?>">Voltar à lista de produtos</a></section>
<?php else: ?>
    <section class="product-detail container">
        <nav class="breadcrumbs" aria-label="Você está aqui"><a href="<?= e(app_url('index.php')) ?>">Início</a><span>/</span><a href="<?= e(app_url('produtos.php')) ?>">Produtos</a><span>/</span><span><?= e($produto['nome']) ?></span></nav>
        <div class="detail-layout">
            <div class="detail-image">
                <?php if (!empty($produto['imagem'])): ?><img src="<?= e(app_url($produto['imagem'])) ?>" alt="<?= e($produto['nome']) ?>">
                <?php else: ?><span class="product-image-placeholder">Imagem não enviada</span><?php endif; ?>
            </div>
            <div class="detail-copy">
                <span class="eyebrow"><?= e($produto['categoria_nome']) ?></span>
                <h1><?= e($produto['nome']) ?></h1>
                <p class="detail-price"><?= e(dinheiro($produto['preco'])) ?></p>
                <div class="silver-rule"></div>
                <h2>Sobre a peça</h2><p class="detail-description"><?= nl2br(e($produto['descricao'])) ?></p>
                <div class="detail-spec"><h3>Tamanhos disponíveis</h3><div class="chip-list"><?php foreach (formatar_lista($produto['tamanhos']) as $item): ?><span><?= e($item) ?></span><?php endforeach; ?></div></div>
                <div class="detail-spec"><h3>Cores disponíveis</h3><div class="chip-list"><?php foreach (formatar_lista($produto['cores']) as $item): ?><span><?= e($item) ?></span><?php endforeach; ?></div></div>
                <p class="detail-note">Esta versão é apenas para consulta de produtos. Não há compra ou pagamento pelo site.</p>
                <a class="button button-outline" href="<?= e(app_url('produtos.php')) ?>">← Voltar à lista</a>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
