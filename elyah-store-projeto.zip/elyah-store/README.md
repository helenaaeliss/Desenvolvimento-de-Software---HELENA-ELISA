# Elyah Store

Projeto escolar de loja feminina em PHP + MySQL, preparado para XAMPP e phpMyAdmin. O código é direto e sem framework. Inclui página pública, busca e filtro de produtos, cadastro de clientes, login e painel administrativo protegido para gerenciar produtos. Não implementa compras nem pagamentos.

## Começar

1. Leia o [manual de instalação e funcionamento](docs/README.md).
2. Importe [`sql/elyah_store.sql`](sql/elyah_store.sql) pelo phpMyAdmin.
3. Copie `config/config.example.php` para `config/config.local.php` e ajuste o MySQL local.
4. Crie o primeiro administrador em `admin/primeiro_admin.php` pelo `localhost` e apague esse arquivo depois.
5. Abra `http://localhost/elyah-store/`.

O SQL não tem senha administrativa. As fotos do catálogo são apenas de demonstração e estão creditadas em [`docs/CREDITOS_IMAGENS.md`](docs/CREDITOS_IMAGENS.md). Os espaços para a logo e banners originais estão descritos em `imagens/marca/README.md`.
