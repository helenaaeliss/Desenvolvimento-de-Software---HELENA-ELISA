# Identidade visual original

As capturas recebidas mostram a logo e um banner dentro das telas, mas não são arquivos independentes prontos para uso. Este diretório fica reservado para os arquivos originais da Elyah Store.

Quando os originais estiverem disponíveis, coloque-os aqui (por exemplo, `logo-elyah.svg` e `banner-principal.jpg`) e substitua os espaços reservados indicados em `includes/header.php`, `login.php`, `cadastro.php`, `admin/primeiro_admin.php` e no banner da página `index.php`. Preserve os arquivos oficiais sem redesenhá-los.
