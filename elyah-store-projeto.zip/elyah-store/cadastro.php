<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Criar conta';
$erro = '';
$nome = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim((string) ($_POST['nome'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $senha = (string) ($_POST['senha'] ?? '');
    $confirmacao = (string) ($_POST['confirmacao'] ?? '');
    if (mb_strlen($nome) < 3 || mb_strlen($nome) > 120) {
        $erro = 'Informe seu nome completo (entre 3 e 120 caracteres).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $erro = 'Informe um e-mail válido.';
    } elseif (strlen($senha) < 8) {
        $erro = 'A senha precisa ter pelo menos 8 caracteres.';
    } elseif ($senha !== $confirmacao) {
        $erro = 'A confirmação de senha não confere.';
    } else {
        try {
            $pdo = app_db();
            $consulta = $pdo->prepare('SELECT id FROM clientes WHERE email = :email LIMIT 1');
            $consulta->execute(['email' => $email]);
            $emailDuplicado = (bool) $consulta->fetch();
            if (!$emailDuplicado) {
                $consulta = $pdo->prepare('SELECT id FROM administradores WHERE email = :email LIMIT 1');
                $consulta->execute(['email' => $email]);
                $emailDuplicado = (bool) $consulta->fetch();
            }
            if ($emailDuplicado) {
                $erro = 'Este e-mail já está cadastrado.';
            } else {
                $hash = password_hash($senha, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare('INSERT INTO clientes (nome, email, senha_hash) VALUES (:nome, :email, :senha_hash)');
                $stmt->execute(['nome' => $nome, 'email' => $email, 'senha_hash' => $hash]);
                flash('sucesso', 'Cadastro concluído. Entre com seu e-mail e senha.');
                redirecionar('login.php');
            }
        } catch (Exception $erroBanco) {
            error_log('Elyah Store cadastro: ' . $erroBanco->getMessage());
            $erro = 'Não foi possível concluir o cadastro. Verifique a conexão com o banco.';
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#dceeff"><title><?= e($pageTitle) ?> | Elyah Store</title><link rel="stylesheet" href="<?= e(app_url('css/style.css')) ?>"><script src="<?= e(app_url('js/app.js')) ?>" defer></script></head>
<body class="auth-body"><div class="auth-layout">
    <aside class="auth-brand-panel"><a href="<?= e(app_url('index.php')) ?>" class="auth-logo-slot">Logo original<br><small>insira o arquivo aqui</small></a><div class="auth-brand-copy"><span class="eyebrow">ELYAH STORE</span><h1>Seu novo<br><em>começo.</em></h1><p>Descubra peças feitas para acompanhar sua história.</p></div><span class="auth-panel-note">Moda feminina · delicadeza em cada detalhe</span></aside>
    <main class="auth-form-panel"><a class="auth-back" href="<?= e(app_url('index.php')) ?>">← Voltar à loja</a><div class="auth-form-wrap"><span class="eyebrow">CADASTRO DE CLIENTE</span><h2>Crie sua conta.</h2><p class="auth-lead">É simples e leva só um momento.</p>
        <?php if ($erro !== ''): ?><div class="notice notice-erro" role="alert"><?= e($erro) ?></div><?php endif; ?>
        <form method="post" action="<?= e(app_url('cadastro.php')) ?>" class="form-stack">
            <label for="nome">Nome completo</label><input id="nome" name="nome" type="text" autocomplete="name" required maxlength="120" value="<?= e($nome) ?>">
            <label for="email">E-mail</label><input id="email" name="email" type="email" autocomplete="email" required maxlength="190" value="<?= e($email) ?>">
            <label for="senha">Senha <span class="field-hint">mínimo de 8 caracteres</span></label><input id="senha" name="senha" type="password" autocomplete="new-password" minlength="8" required>
            <label for="confirmacao">Confirme sua senha</label><input id="confirmacao" name="confirmacao" type="password" autocomplete="new-password" minlength="8" required>
            <button class="button button-primary button-wide" type="submit">Criar conta</button>
        </form>
        <p class="auth-switch">Já tem cadastro? <a href="<?= e(app_url('login.php')) ?>">Entrar</a></p>
        <p class="auth-admin-hint">Esta conta é de cliente e não dá acesso ao painel administrativo.</p>
    </div></main>
</div></body></html>
