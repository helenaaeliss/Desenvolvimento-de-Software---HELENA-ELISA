<?php
// Copie este arquivo para config.local.php e altere os dados se necessário.
// No XAMPP padrão, o usuário costuma ser root e a senha local fica vazia.
return [
    'base_url' => '/elyah-store', // Altere se o nome da pasta em htdocs for diferente.
    'database' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'elyah_store',
        'user' => 'root',
        'password' => '',
    ],
];
