# Créditos das imagens de demonstração

As imagens abaixo são fotos de terceiros usadas somente para ilustrar os produtos fictícios do catálogo. Elas não representam produtos oficiais da Elyah Store. Consulte a licença original antes de reutilizá-las em outro contexto.

- `imagens/produtos/bolsa-perola.jpg`: Mohaned Tamzini, “Display of Elegant White Leather Purse and Heel”, Pexels. [Página original](https://www.pexels.com/photo/display-of-elegant-white-leather-purse-and-heel-17938771/) · [Licença Pexels](https://www.pexels.com/license/).
- `imagens/produtos/vestido-azul.jpg`: Zulfugar Karimov, “A woman in a light blue dress by the water”, Unsplash. [Página original](https://unsplash.com/photos/a-woman-in-a-light-blue-dress-by-the-water-ehTScig11O4) · [Licença Unsplash](https://unsplash.com/license).
- `imagens/produtos/conjunto-areia.jpg`: Ramo Roso, “Woman in white shirt and black wide-leg pants”, Unsplash. [Página original](https://unsplash.com/photos/woman-in-white-shirt-and-black-wide-leg-pants-9E7s5oyDmxg) · [Licença Unsplash](https://unsplash.com/license).

Os arquivos foram reduzidos para uso no catálogo local. Para a identidade visual real, substitua os espaços reservados pelos arquivos originais da logo e dos banners; não trate estas fotos como materiais oficiais da marca.
