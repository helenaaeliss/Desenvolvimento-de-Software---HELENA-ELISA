# Elyah Store — instalação e apresentação

Este é um projeto escolar de loja feminina feito em PHP, HTML, CSS, JavaScript e MySQL. O código usa páginas PHP diretas e algumas funções compartilhadas para facilitar a leitura. Não usa framework nem compra online. Os produtos e contas são consultados e gravados no MySQL.

## Instalação no XAMPP

1. Extraia a pasta do projeto em `C:\xampp\htdocs\elyah-store` (Windows) ou `/opt/lampp/htdocs/elyah-store` (Linux). Mantenha o nome `elyah-store` ou altere `base_url` em `config/config.local.php`.
2. Abra o XAMPP Control Panel e inicie **Apache** e **MySQL**.
3. Acesse `http://localhost/phpmyadmin/`, clique em **Importar**, escolha `sql/elyah_store.sql` e confirme. O SQL cria o banco `elyah_store`, as quatro tabelas, três categorias e três produtos fictícios.
4. Copie `config/config.example.php` para `config/config.local.php`. Confira host, porta, banco, usuário e senha. No XAMPP padrão local, normalmente o usuário é `root` e a senha fica vazia. Não compartilhe esse arquivo.
5. Acesse `http://localhost/elyah-store/admin/primeiro_admin.php` no próprio computador. Escolha nome, e-mail e senha de administrador. A senha precisa ter pelo menos 12 caracteres. O formulário só funciona em `localhost` e enquanto ainda não existe administrador.
6. Depois de criar a conta, apague o arquivo `admin/primeiro_admin.php`. Isso encerra a configuração inicial. Entre por `http://localhost/elyah-store/login.php`; o painel fica em `http://localhost/elyah-store/admin/`.
7. A loja abre em `http://localhost/elyah-store/`. Clientes podem criar uma conta em `http://localhost/elyah-store/cadastro.php`; esse formulário sempre cria um cliente, não um administrador.

Para imagens do painel, o sistema aceita JPG, PNG e WEBP de até 5 MB. Se o envio falhar, confira no `php.ini` se `file_uploads=On`, `upload_max_filesize` e `post_max_size` permitem arquivos com mais de 5 MB; depois reinicie o Apache.

## Importar o banco pelo phpMyAdmin

Use a opção **Importar** e escolha `sql/elyah_store.sql`. A importação cria as tabelas `categorias`, `administradores`, `clientes` e `produtos`. Ela inclui os produtos de demonstração, mas deixa `administradores` e `clientes` vazias. Não há senha administrativa dentro do SQL.

## Arquivos principais

- `index.php`, `produtos.php`, `produto.php`, `categorias.php`: página inicial, busca, filtro, detalhes e categorias.
- `login.php`, `cadastro.php`, `logout.php`: entrar, criar conta de cliente e sair.
- `admin/`: painel e cadastro, edição e exclusão de produtos.
- `includes/`: conexão, algumas funções comuns e partes reutilizadas das páginas.
- `config/config.example.php`: exemplo sem senha; copie para `config/config.local.php` e ajuste no seu computador.
- `sql/elyah_store.sql`: banco MySQL para importar.
- `css/style.css` e `js/app.js`: aparência responsiva e menu móvel.
- `imagens/produtos/`: fotos demonstrativas com créditos em `CREDITOS_IMAGENS.md`.
- `imagens/marca/`: instruções para inserir a logo e os banners oficiais quando tiver os arquivos originais.
- `uploads/`: destino das imagens enviadas pelo administrador.

## Explicação simples do sistema

O arquivo `includes/bootstrap.php` abre a conexão PDO com o MySQL. As páginas públicas usam `SELECT` para buscar produtos e categorias. A pesquisa e o filtro colocam condições na consulta; `produto.php` busca um item pelo ID.

No cadastro, o PHP confere os dados e usa `password_hash` antes de salvar a senha. No login, procura o e-mail nas tabelas de administrador e cliente e compara a senha com `password_verify`. Depois do login, a sessão guarda o ID e o tipo de conta. As páginas dentro de `admin/` chamam `exigir_administrador()` para bloquear quem não é administrador.

O painel grava produtos usando `INSERT` e `UPDATE`, e apaga com `DELETE`. As consultas que recebem dados do formulário usam parâmetros PDO. As imagens são verificadas e salvas em `uploads/`; o banco guarda o caminho do arquivo. Não há carrinho, compra ou pagamento.

As imagens enviadas da marca eram capturas de tela, não arquivos independentes. Por isso, o cabeçalho, telas de login/cadastro e banner têm espaços preparados. Para trocar, siga `imagens/marca/README.md` e mantenha os arquivos originais sem redesenhá-los.

## Verificações realizadas

Foram testados PHP 8.3 e MariaDB neste ambiente: sintaxe dos arquivos PHP, importação do SQL, carregamento das páginas, cadastro e login de cliente, bloqueio do cliente no painel, criação e login de administrador, busca e detalhes, rejeição de arquivo que não é imagem, upload JPG, cadastro/edição/exclusão de produto e senha salva como hash. Também foi repetida a importação SQL para confirmar que os produtos demonstrativos não são duplicados.

Não foi instalado o XAMPP do Windows neste ambiente. Antes da apresentação, repita os passos de importação e navegação no XAMPP do computador do curso e confira o layout em celular/tablet no navegador. As fotos são exemplos externos, não produtos oficiais.

## Publicação futura

Para publicar, use hospedagem com PHP e MySQL, domínio e HTTPS. Crie um banco e um usuário MySQL próprios, configure a senha fora dos arquivos públicos, remova `admin/primeiro_admin.php`, mantenha erros técnicos fora da tela e faça backups. O XAMPP com usuário `root` e senha vazia é apenas para uso local. Faça uma cópia de teste com dados fictícios antes de colocar qualquer conteúdo real no ar.
