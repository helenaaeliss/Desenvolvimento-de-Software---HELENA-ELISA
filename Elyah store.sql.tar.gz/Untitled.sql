CREATE TABLE `administradores` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) UNIQUE NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `ativo` boolean NOT NULL DEFAULT true,
  `criado_em` timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE `categorias` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `nome` varchar(80) UNIQUE NOT NULL,
  `descricao` varchar(255),
  `imagem` varchar(255),
  `ativo` boolean NOT NULL DEFAULT true,
  `criado_em` timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE `produtos` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `categoria_id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `imagem_principal` varchar(500) NOT NULL,
  `disponivel` boolean NOT NULL DEFAULT true,
  `criado_em` timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  `atualizado_em` timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE `imagens_produtos` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `produto_id` int NOT NULL,
  `url_imagem` varchar(500) NOT NULL,
  `descricao` varchar(150),
  `ordem` int NOT NULL DEFAULT 1
);

CREATE TABLE `variacoes_produtos` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `produto_id` int NOT NULL,
  `tamanho` varchar(20) NOT NULL,
  `cor` varchar(50) NOT NULL,
  `quantidade_estoque` int NOT NULL DEFAULT 0,
  `preco_adicional` decimal(10,2) NOT NULL DEFAULT 0
);

CREATE INDEX `produtos_index_0` ON `produtos` (`categoria_id`);

CREATE INDEX `produtos_index_1` ON `produtos` (`nome`);

CREATE UNIQUE INDEX `variacoes_produtos_index_2` ON `variacoes_produtos` (`produto_id`, `tamanho`, `cor`);

ALTER TABLE `produtos` COMMENT = 'Informacoes principais de cada roupa';

ALTER TABLE `variacoes_produtos` COMMENT = 'Permite cadastrar diferentes tamanhos e cores para uma roupa';

ALTER TABLE `produtos` ADD FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

ALTER TABLE `imagens_produtos` ADD FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`);

ALTER TABLE `variacoes_produtos` ADD FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`);
